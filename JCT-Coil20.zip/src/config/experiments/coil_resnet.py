from config.defaults import Experiment,JCT, DDC, Fusion, Loss, Dataset, Optimizer,resnet


coil_resnet_contrast = Experiment(
    dataset_config=Dataset(name="coil"),
    model_config=JCT(
        backbone_configs=(
            resnet(block="BasicBlock"),
            resnet(block="BasicBlock"),
            resnet(block="BasicBlock"),
        ),
        fusion_config=Fusion(method="weighted_mean", n_views=3),
        projector_config=None,
        cm_config=DDC(n_clusters=20),
        loss_config=Loss(
            funcs="ddc_1|ddc_2|ddc_3|instance_cluster|contrast",
            delta=20.0
        ),
        optimizer_config=Optimizer()
    ),
)


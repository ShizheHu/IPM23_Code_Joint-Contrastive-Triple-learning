# Joint Contrastive Triple-learning for Deep Multi-view Clustering

We have built new state-of-the-art performance on several benchmarked datasets.

> Abstract: Deep multi-view clustering (MVC) is to mine and employ the complex relationships among views to learn the compact data clusters with deep neural networks in an unsupervised manner. The more recent deep contrastive learning (CL) methods have shown promising performance in MVC by learning cluster-oriented deep feature representations, which is realized by contrasting the positive and negative sample pairs. However, most existing deep contrastive MVC methods only focus on the one-side contrastive learning, such as feature-level or cluster-level contrast, failing to integrating the two sides together or bringing in more important aspects of contrast. Additionally, most of them work in a separate two-stage manner, i.e., first feature learning and then data clustering, failing to mutually benefit each other. To fix the above challenges, in this paper we propose a novel joint contrastive triple-learning framework to learn multi-view discriminative feature representation for deep clustering, which is threefold, i.e., feature-level alignment-oriented and commonality-oriented CL, and cluster-level consistency-oriented CL. The former two submodules aim to contrast the encoded feature representations of data samples in different feature levels, while the last contrasts the data samples in the cluster-level representations. Benefiting from the triple contrast, the more discriminative representations of views can be obtained. Meanwhile, a view weight learning module is designed to learn and exploit the quantitative complementary information across the learned discriminative features of each view. Thus, the contrastive triple-learning module, the view weight learning module and the data clustering module with these fused features are jointly performed, so that these modules are mutually beneficial. The extensive experiments on several challenging multi-view datasets show the superiority of the proposed method over many state-of-the-art methods, especially the large improvement of 15.5% and 8.1% on Caltech-4V and CCV in terms of accuracy. Due to the promising performance on visual datasets, the proposed method can be applied into many practical visual applications such as visual recognition and analysis.

**If you found this code helps your work, do not hesitate to cite my paper or star this repo!**

## Installation
Requires Python >= 3.8 (tested on 3.8)

To install the required packages, run:
```
pip install -r requirements.txt
```

## Datasets
### Included dataset
The following datasets are included as files in this project:

- `Caltech-2V` 
- `Caltech-3V` 
- `Caltech-4V` 
- `Caltech-5V` 

### Datasets that require additional downloads

- `ccv` (CCV): Download the files from [here](https://www.ee.columbia.edu/ln/dvmm/CCV/), and place them in 
`data/raw/CCV`.
- `coil` (COIL-20). Download the processed files from 
[here](https://www.cs.columbia.edu/CAVE/software/softlib/coil-20.php), and place them in `data/raw/COIL`.

After downloading and extracting the files, run
``` Bash
python -m data.make_dataset ccv coil
```
to generate training-ready versions of CCV and COIL-20.


## Running an experiment
In the `src` directory, run:
```
python -m models.train -c <config_name> 
```
where `<config_name>` is the name of an experiment config from one of the files in `src/config/experiments/`.

## Evaluating an experiment
Run the evaluation script:
```Bash
python -m models.evaluate -c <config_name> \ # Name of the experiment config
                          -t <tag> \         # The unique 8-character ID assigned to the experiment when calling models.train
                          --plot             # Optional flag to plot the representations before and after fusion.
```
